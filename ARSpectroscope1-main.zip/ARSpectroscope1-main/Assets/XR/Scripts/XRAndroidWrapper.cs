version https://git-lfs.github.com/spec/v1
oid sha256:6e80f38d78396c98513594203055d48642f246cad0aa14deacaa43b16e5008d3
size 4718
