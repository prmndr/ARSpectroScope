version https://git-lfs.github.com/spec/v1
oid sha256:bef81da13b6f2cec14b45368ddcfcb5d391eddb15c6ae8d8312fec988ece8e70
size 19606
