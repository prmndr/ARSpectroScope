version https://git-lfs.github.com/spec/v1
oid sha256:0c928ca5d3edc5efac972ea6969b7b609e324dd5cd446dd163fbb22735304e19
size 12314
