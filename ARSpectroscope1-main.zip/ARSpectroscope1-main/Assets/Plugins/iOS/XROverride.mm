version https://git-lfs.github.com/spec/v1
oid sha256:1ce9a17ec4574fe44318b5f49462224ab53cf94d21b39250e815388903bc9b63
size 1320
