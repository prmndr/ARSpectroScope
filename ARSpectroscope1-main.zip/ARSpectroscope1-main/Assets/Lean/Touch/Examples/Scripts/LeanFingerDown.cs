version https://git-lfs.github.com/spec/v1
oid sha256:a0e4137df2270af86ea759e8345c15092ee9d02788ae3834aedd680ab22b68bc
size 3676
