version https://git-lfs.github.com/spec/v1
oid sha256:5f3d942ce5357f4f510d67a115a4ee7db5e45159072015762dd29904de1e6e42
size 5325
