version https://git-lfs.github.com/spec/v1
oid sha256:1172c050bbe8568a290dc094edf615c8033d0dcce7f080c0aa586777714dd7f2
size 11706
