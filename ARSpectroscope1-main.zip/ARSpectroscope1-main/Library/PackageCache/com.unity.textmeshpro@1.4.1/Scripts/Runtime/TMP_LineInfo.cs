version https://git-lfs.github.com/spec/v1
oid sha256:5bb2573c50c9271fccb57acffdd2e274d3acdeb74fca8c27eb44e845565ed47b
size 1423
