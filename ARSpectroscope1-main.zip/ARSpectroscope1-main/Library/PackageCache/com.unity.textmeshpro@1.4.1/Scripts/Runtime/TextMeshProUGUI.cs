version https://git-lfs.github.com/spec/v1
oid sha256:ff0f60f72d447305e331ecb924a36d0933eb366dbf9c8d1b125788be5aeaf2be
size 20856
