version https://git-lfs.github.com/spec/v1
oid sha256:17bc3139df6fe72ff4e86fcd7e582b61b6d25e5a5fbb429f82c7b0770b25d820
size 5190
