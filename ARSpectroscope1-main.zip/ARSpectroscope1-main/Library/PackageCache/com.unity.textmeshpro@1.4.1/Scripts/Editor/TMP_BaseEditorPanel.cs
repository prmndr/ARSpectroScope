version https://git-lfs.github.com/spec/v1
oid sha256:2e16027cbfd029fbeaceade34236ec3981b72a255627a93b3847a0b7e8b0a5c4
size 50624
