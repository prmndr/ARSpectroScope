version https://git-lfs.github.com/spec/v1
oid sha256:fe9f6c2551680d81ee7524e1f8d0a8ed249bd25114df831a6c1084e5b1c76b50
size 3347
