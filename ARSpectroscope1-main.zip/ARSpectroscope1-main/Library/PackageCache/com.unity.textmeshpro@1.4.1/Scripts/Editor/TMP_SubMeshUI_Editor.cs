version https://git-lfs.github.com/spec/v1
oid sha256:746de43b0cd8d2f956a89275e20faaf4b1161f1cf8a01f2bbb70abca5c99d839
size 3072
