version https://git-lfs.github.com/spec/v1
oid sha256:c6e7192f46afa267ec12a52d288483af5f0e3edaad1ced5ec192091086d33fe0
size 1426
