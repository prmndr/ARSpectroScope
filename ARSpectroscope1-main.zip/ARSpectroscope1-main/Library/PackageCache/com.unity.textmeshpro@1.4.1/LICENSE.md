version https://git-lfs.github.com/spec/v1
oid sha256:2257b0253ea7c8dfd78a14a56f76a19ba071f9d796923f033f5092d695a8fa19
size 481
