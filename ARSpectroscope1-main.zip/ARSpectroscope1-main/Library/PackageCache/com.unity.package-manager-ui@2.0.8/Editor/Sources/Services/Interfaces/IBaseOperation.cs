version https://git-lfs.github.com/spec/v1
oid sha256:d11732604c6b66ee92e84250a457dd0632a9f6c2aac63fc6b2b97229014c97b1
size 290
