version https://git-lfs.github.com/spec/v1
oid sha256:b171fdd050fc5ef0470845e13fef96b26aeb387d0492cdfc38173a85741a0284
size 1082
