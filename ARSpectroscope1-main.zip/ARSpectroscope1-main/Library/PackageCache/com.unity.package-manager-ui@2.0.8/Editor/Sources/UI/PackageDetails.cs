version https://git-lfs.github.com/spec/v1
oid sha256:e3296300e5586d97b16881714df4d190082d69e5d1401adce67d74ec08c97e5c
size 28123
