version https://git-lfs.github.com/spec/v1
oid sha256:98a5973997d66104c48bc1e034e347b597e2ba4387247d6b753a17ed8701b1b4
size 334
