version https://git-lfs.github.com/spec/v1
oid sha256:315a1e302e86d81af109688f7a4242cfa41b7e3aa9668473e7aa4dc07535d1c6
size 22227
