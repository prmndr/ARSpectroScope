version https://git-lfs.github.com/spec/v1
oid sha256:2f0352aed0ef7ecc2205288803bda073750c9bc96337c9ccd1196c7997c7ee00
size 224
