version https://git-lfs.github.com/spec/v1
oid sha256:d29237efdbfe478cc02ce27ba53d7de6807c8e1a21645bcda0077db930a9ed2c
size 575
