version https://git-lfs.github.com/spec/v1
oid sha256:f99047627c144d7ddc279cbaa5c83dd6151a3ed18ad28c3f9018652196b0ff91
size 592
